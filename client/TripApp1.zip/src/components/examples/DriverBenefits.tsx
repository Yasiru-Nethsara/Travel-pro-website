import DriverBenefits from '../DriverBenefits'

export default function DriverBenefitsExample() {
  return <DriverBenefits />
}
